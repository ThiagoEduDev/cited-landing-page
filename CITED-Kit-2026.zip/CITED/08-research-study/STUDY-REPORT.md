# Who Is Actually Blocking AI Crawlers?

**An examination of 49 marketing, SEO and web-services websites**
Data collected 21 September 2026 · Raw dataset: `dataset-robots-sweep-2026-09-21.csv`

---

## Headline finding

**83.7% of the sites examined have no AI crawler directives in `robots.txt` at all.**

They are not blocking AI crawlers. They are also not allowing them deliberately. They have simply never addressed the question — the permissive outcome is a side-effect of an absent decision, not a decision.

Only **16.3%** had taken any explicit position, and only **4.1%** block the crawlers that actually drive AI citations.

**This contradicts the assumption I started with.** I expected to find widespread blocking from security-plugin defaults and 2023-era "block the AI scrapers" advice. In this sample, that is not what is happening. The story is not obstruction — it is inattention.

---

## Method

**Question:** What proportion of professional marketing and web-services websites have explicit `robots.txt` directives for major AI crawlers, and what do those directives say?

**Universe.** A convenience sample of recognisable companies in the marketing, SEO, web-platform, hosting, review-platform and service-marketplace sectors. Domains were enumerated by hand from category knowledge — SEO tools, enterprise SEO platforms, SEO publishers, website builders, hosting providers, martech platforms, review platforms and service marketplaces.

**This is not a random sample of the web, and it is not a sample of small local businesses.** It is a sample of the industry that sells search visibility. That was deliberate: it is the industry our intended customer works in, and "do the experts practise what they sell?" is a meaningful question.

**Measurement.** For each domain, `https://<domain>/robots.txt` was fetched and coded for eight user-agents:

`GPTBot`, `OAI-SearchBot`, `ChatGPT-User`, `PerplexityBot`, `ClaudeBot`, `Google-Extended`, `CCBot`, `Bytespider`

Each agent coded as:
- **A** — named in the file and *not* given `Disallow: /`
- **B** — given `Disallow: /`
- **N** — not mentioned anywhere in the file

Plus a flag for whether `User-agent: *` carries a blanket `Disallow: /`.

**Instrument validation.** Before trusting the results, the method was tested against sites expected to produce positives. `hostinger.com` returned a mixed configuration (six agents named and allowed, `CCBot` and `Bytespider` blocked), and `trustpilot.com` returned a full block. The instrument detects both permissive and restrictive configurations correctly, so the large number of "N" readings reflects genuinely silent files rather than measurement failure.

**Sample size.** 62 domains attempted, **49 successfully retrieved (79.0%)**. 13 could not be measured.

**Date:** all observations collected 21 September 2026.

---

## Results

### Has the site made any decision at all?

| | Sites | Share |
|---|---|---|
| No AI crawler directives whatsoever | 41 | **83.7%** |
| Names at least one AI agent explicitly | 8 | 16.3% |
| Blocks at least one citation-driving agent | 2 | **4.1%** |
| Blanket `User-agent: * / Disallow: /` | 2 | 4.1% |

### By agent

| Agent | Named & allowed | Blocked | Not mentioned |
|---|---|---|---|
| `GPTBot` | 6 | 1 | 42 |
| `OAI-SearchBot` | 5 | 1 | 43 |
| `ChatGPT-User` | 6 | 1 | 42 |
| `PerplexityBot` | 6 | 1 | 42 |
| `ClaudeBot` | 7 | 1 | 41 |
| `Google-Extended` | 5 | 1 | **43 (87.8%)** |
| `CCBot` | 3 | 2 | 44 |
| `Bytespider` | 2 | 2 | 45 |

### Sample composition

| Category | n |
|---|---|
| SEO tools | 11 |
| Website platforms | 7 |
| Hosting providers | 6 |
| Enterprise SEO platforms | 6 |
| Martech platforms | 5 |
| SEO publishers | 4 |
| SEO plugins | 2 |
| AI content tools | 2 |
| Review platforms | 2 |
| Service marketplaces | 2 |
| PPC tools | 1 |
| Agency directories | 1 |

---

## Notable individual observations

**`trustpilot.com` blocks every crawler examined, site-wide.** Its `robots.txt` carries a blanket `User-agent: * / Disallow: /` and explicit blocks on all eight agents.

This is the most consequential single observation in the study. Trustpilot is a platform businesses actively use to accumulate third-party credibility — exactly the kind of independent corroboration an answer engine looks for. If its review pages are not retrievable by AI crawlers, the reputational signal a business builds there may not reach the systems that business hopes will cite it. *(Whether these pages reach AI systems through other routes — licensing agreements, APIs, syndication — was not measured and cannot be inferred from `robots.txt` alone.)*

**`majestic.com` also carries a blanket `Disallow: /`.** A long-established SEO tool company that is, by its own configuration file, entirely absent from AI crawling.

**`hostinger.com` is the only site in the sample with the "cited, not trained" configuration** — allowing the six search and live-fetch agents that drive citations while blocking `CCBot` and `Bytespider`, which primarily feed training corpora. This is the most deliberate configuration observed, and exactly one site out of 49 had it.

**The eight sites that made an explicit decision** are `hostinger.com`, `klaviyo.com`, `squarespace.com`, `frase.io`, `jasper.ai`, `spyfu.com`, `capterra.com` and `trustpilot.com`. Seven of those eight chose to allow.

---

## Limitations — read these before quoting anything above

1. **Selection bias toward permissive sites, and it is substantial.** 13 of 62 domains could not be retrieved. The failures were disproportionately major publishers — `nytimes.com`, `reuters.com`, `wired.com`, `theguardian.com`, `theverge.com` — precisely the category most likely to block AI crawlers, and several returned `403 Forbidden` to our fetcher. **The true block rate across the web is almost certainly higher than the 4.1% measured here.** This figure should be read as a floor for this sector, not an estimate for the web.

2. **Not a random sample.** Domains were chosen by hand. No claim of statistical representativeness is made, and no confidence intervals are offered because none would be meaningful.

3. **Not small businesses.** This sample is mid-market and enterprise companies in one industry. Small local business sites — which more often run stock CMS configurations, security plugins and agency-installed defaults — were not measured and may behave completely differently. **That remains an open question and a worthwhile follow-up study.**

4. **`robots.txt` is not the whole picture.** Sites can block AI crawlers at the CDN or WAF layer, by IP, or by user-agent filtering at the edge — none of which appears in `robots.txt`. A file that permits a crawler does not prove the crawler gets through.

5. **Absence of a rule is not consent.** Coding an agent as "not mentioned" means the default applies. It does not mean the operator knowingly allowed it.

6. **Single point in time.** One snapshot, 21 September 2026. No trend claim is possible from a single observation.

7. **Coding was automated.** Each file was parsed by an automated reader rather than a human. The instrument was validated against known positives and negatives, but individual coding errors on unusual file structures are possible.

---

## What this means

### For businesses

The urgent problem is probably not that you are blocked. It is that **nothing about your AI visibility has been decided by anyone**. No crawler policy, no `llms.txt`, no entity markup strategy — the default state is "technically reachable and otherwise invisible."

Being reachable is the floor, not the goal. A crawler that can fetch your page still has to be able to identify who you are, find a passage worth quoting, and see the claim corroborated somewhere else.

### For the people who sell search visibility

Only one company in 49 had configured the deliberate "cited, not trained" split. Seven had made any explicit allow decision. This is not an industry that has worked out its position — it is an industry that has not looked.

### The honest caveat

If you go and check your own clients' `robots.txt` files expecting to find blocked crawlers, **this data suggests you mostly will not**. You will find silence. That is a different conversation — a better one, arguably, because it is about strategy rather than a misconfiguration — but it is not the same conversation.

---

## Reproducing this

The dataset is in `dataset-robots-sweep-2026-09-21.csv` with one row per domain and one column per agent. Every observation is a direct reading of a publicly available file. Anyone can verify any row by visiting `https://<domain>/robots.txt` — though results may have changed since the collection date.

**Suggested follow-up:** the same method applied to 100 small local businesses in a single category and city. That is the population most relevant to a working consultant, and it is the population this study does not cover.
