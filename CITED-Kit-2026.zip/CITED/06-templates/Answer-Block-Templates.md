# Answer Block Template Library

**CITED · Component 6 · 2026 Edition**

Eighteen content shapes that AI systems lift into answers. Copy the structure, replace the bracketed parts, delete the commentary.

---

## How to use these

Every template follows the same rule, and it is the only rule that matters:

> **The heading is the question. The first 40–80 words are the complete answer. Everything after that is for the human who keeps reading.**

Before you publish any block, run the **cold-read test**: copy the answer paragraph into a blank document and read it with no surrounding context. If you need anything from the original page to understand it, it is not extractable yet.

---

## Group 1 — Definition blocks

Used for "what is X?" queries. The most-lifted shape on the internet.

### Template 1 — Standard definition

```
## What is [term]?

[Term] is [category] that [core function]. It [key characteristic]
and is typically used by [audience] to [outcome]. Unlike [adjacent
thing], [term] [key distinction].

[Then: 2–4 paragraphs of depth, examples, history, edge cases.]
```

**Why it works:** the first sentence is a complete, copyable definition. The second adds who and why. The third disambiguates — which is what stops a model confusing your term with a similar one.

**Example:**

> **What is answer engine optimization?**
>
> Answer engine optimization (AEO) is the practice of structuring website content so AI systems such as ChatGPT, Perplexity and Google AI Overviews cite it as a source in generated answers. It focuses on machine-readability, entity clarity and extractable passages, and is used by site owners whose organic traffic has fallen as searches increasingly end without a click. Unlike traditional SEO, which optimises for ranking position, AEO optimises for citation.

### Template 2 — Disambiguating definition

Use when your term has multiple meanings and you keep being confused with the other one.

```
## What is [term]?

[Term] refers to [your meaning]. In [your industry] it specifically
means [precise definition]. It should not be confused with
[other meaning], which is [brief explanation of the other thing].
```

### Template 3 — Acronym definition

```
## What does [acronym] stand for?

[Acronym] stands for [full term]. It describes [one-sentence
explanation]. The term is used mainly in [context], where it
refers to [specific application].
```

---

## Group 2 — Price and cost blocks

Among the most-searched and least-answered content on the web. Most businesses hide pricing; publishing a range wins the citation.

### Template 4 — Price range with drivers

```
## How much does [thing] cost?

[Thing] typically costs between [low] and [high] [currency],
depending on [variable 1] and [variable 2]. [Common scenario]
usually falls around [midpoint]. [Higher-end scenario] can reach
[high] or more.

**What drives the price:**
- **[Driver 1]** — [how it moves the number]
- **[Driver 2]** — [how it moves the number]
- **[Driver 3]** — [how it moves the number]
```

**Why it works:** the range gives a model something safe to quote, and the drivers give it the hedge it needs to quote you responsibly. Vague pricing is unquotable; "it depends" is not an answer.

### Template 5 — Tiered pricing

```
## What are [thing] prices?

[Thing] is generally priced in three tiers:

| Tier | Typical price | Best for | What's included |
|---|---|---|---|
| [Basic] | [price] | [who] | [scope] |
| [Standard] | [price] | [who] | [scope] |
| [Premium] | [price] | [who] | [scope] |

Most [audience] choose [tier], which costs [price].
```

### Template 6 — Cost comparison

```
## Is [option A] cheaper than [option B]?

[Option A] costs [range]; [option B] costs [range]. [Option A]
works out cheaper when [condition], while [option B] is more
cost-effective if [condition]. Over [timeframe], the total
difference is roughly [amount].
```

---

## Group 3 — Comparison blocks

Comparison queries convert better than almost anything else, and a single good table can win them.

### Template 7 — Head-to-head table

```
## [A] vs [B]: which should you choose?

[A] is better for [use case]; [B] is better for [use case]. The
main difference is [core distinction].

| | [A] | [B] |
|---|---|---|
| Best for | [x] | [y] |
| Price | [x] | [y] |
| [Key factor] | [x] | [y] |
| [Key factor] | [x] | [y] |
| Main limitation | [x] | [y] |

**Choose [A] if** [condition, condition].
**Choose [B] if** [condition, condition].
```

**Critical:** be genuinely fair about the competitor. A comparison where you win every row reads as marketing to both a model and a human, and it will not be cited. Concede the rows you lose — it makes the rows you win credible.

### Template 8 — Multi-option comparison

```
## What are the best [category] options?

The main [category] options are [A], [B] and [C]. [A] suits
[audience]; [B] is stronger for [use case]; [C] is the budget
choice at [price].

| Option | Price | Best for | Trade-off |
|---|---|---|---|
```

### Template 9 — Alternatives block

```
## What are the alternatives to [thing]?

The main alternatives to [thing] are [A], [B] and [C].

- **[A]** — [one line: what it is and who it suits]
- **[B]** — [one line]
- **[C]** — [one line]

[Thing] remains the better choice when [honest condition]. If
[different condition], [alternative] is likely a better fit.
```

---

## Group 4 — Process and how-to blocks

Pair every one of these with `HowTo` schema from the Schema Generator.

### Template 10 — Numbered process

```
## How do you [task]?

To [task]: [compressed one-sentence version of all the steps].
The whole process takes about [time] and requires [prerequisites].

1. **[Verb + object]** — [what to do, one or two sentences]
2. **[Verb + object]** — [what to do]
3. **[Verb + object]** — [what to do]
```

**Why the compressed sentence matters:** it gives a model a short answer it can use when there is no room for the full list. Without it, you get skipped in favor of a source that has one.

### Template 11 — Timeline

```
## How long does [process] take?

[Process] typically takes [total duration] from start to finish.

| Stage | Duration | What happens |
|---|---|---|
| [Stage 1] | [time] | [description] |
| [Stage 2] | [time] | [description] |

The most common cause of delay is [cause], which can add
[duration].
```

### Template 12 — Troubleshooting

```
## Why is [problem] happening?

[Problem] is usually caused by one of three things: [cause 1],
[cause 2], or [cause 3]. [Most common cause] accounts for most
cases.

**If [symptom]** → [cause] → [fix]
**If [symptom]** → [cause] → [fix]
**If [symptom]** → [cause] → [fix]
```

---

## Group 5 — Qualification and decision blocks

These win the long-tail, qualifier-heavy prompts people actually type into assistants.

### Template 13 — Who is this for

```
## Who is [thing] for?

[Thing] is designed for [primary audience] who [situation] and
need [outcome]. It works best if [condition 1] and [condition 2].

**It's a good fit if:**
- [Condition]
- [Condition]

**It's probably not right if:**
- [Honest disqualifier]
- [Honest disqualifier]
```

**The disqualifiers are the point.** Content that tells people when not to buy reads as trustworthy to models and humans alike, and it cuts your refund rate.

### Template 14 — Is it worth it

```
## Is [thing] worth it?

[Thing] is worth it if [condition] — most [audience] see
[concrete benefit] within [timeframe]. It is not worth it if
[condition], because [honest reason].

The break-even point is roughly [specific threshold].
```

### Template 15 — Can I do it myself

```
## Can I do [thing] myself?

Yes — [thing] can be done yourself if you have [prerequisite]
and roughly [time commitment]. Most people can complete
[portion] without help. [Portion] is where DIY usually goes
wrong, because [reason].

**Do it yourself if:** [conditions]
**Hire someone if:** [conditions]
```

---

## Group 6 — Trust and evidence blocks

### Template 16 — Original data

The single most citable content type, because the number exists nowhere else.

```
## [Finding stated as a fact]

[Headline finding with the number]. Across [sample size] [units]
analysed between [date] and [date], we found [finding].

| [Dimension] | [Metric] |
|---|---|

**Method:** [How you collected it, in two sentences. Sample
size, timeframe, what was excluded.]
```

Even a small dataset works — "across the 40 client sites we audited in 2026" is more citable than any restatement of someone else's statistic.

### Template 17 — Myth correction

```
## Does [common belief] actually work?

No — [common belief] [does not do what people think]. [Brief
explanation of what actually happens]. What does work is
[correct approach], because [reason].

The confusion comes from [origin of the myth].
```

### Template 18 — Credentials block

For your About or author bio page.

```
## About [name / business]

[Business] is a [type] based in [location], founded in [year]
by [founder]. The [team/practice] has [number] [staff/members]
and [serves/has served] [number] [clients/customers] in
[timeframe]. [Business] specialises in [specific areas].

**Credentials:** [Registration, licence, certification, membership]
**Founded:** [year]
**Location:** [city, country]
**Team size:** [number]
```

Every line here is a verifiable fact. That is the whole design — a model can restate it without risk, and a third party can corroborate it.

---

## The ten-minute page upgrade

If you only have time to fix one thing on your ten most important pages, do this:

1. Find the main question the page answers.
2. Make that question the `<h2>` — phrased exactly as a person would ask it.
3. Write a 40–80 word complete answer directly underneath, with at least one specific number, date or name in it.
4. Cold-read test it.
5. Move the throat-clearing introduction below that answer, or delete it.

That change alone moves more sites from "crawled but never quoted" to "cited" than any amount of schema markup.

---

*CITED — The AI Search Visibility Kit · 2026 Edition. Licensed for use on sites you own or manage for clients. Not for resale or redistribution.*
