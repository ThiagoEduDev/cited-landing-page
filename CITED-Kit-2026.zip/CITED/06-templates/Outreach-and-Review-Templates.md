# Outreach & Review Templates

**CITED · Component 6 · 2026 Edition**

Scripts for the Evidence layer — the one that decides close calls and the one every checklist under-weights.

Replace everything in `[brackets]`. Delete anything that is not true of you. **Never send a template you have not read.**

---

## Part 1 — Review requests

### The three rules

1. **Ask within hours of completion**, while the experience is vivid. A request sent a week later gets a fraction of the response.
2. **Ask a specific question**, so you get a specific, extractable review. "Great service!" is worth nothing to an answer engine. "They replaced our boiler in Headingley the same day" is worth ten of them.
3. **Never gate the request to happy customers only, never incentivize a positive review, never buy one.** It breaches every major platform's terms and consumer-protection law in most jurisdictions, and detection has become very good.

### Template A — Email, same day

> **Subject:** Quick favour, [First name]?
>
> Hi [First name],
>
> Thanks for choosing us for [specific service] [today/this week] — it was good working with you.
>
> If you have two minutes, would you leave us a short review? It genuinely helps other [customer type] in [location] find us.
>
> **[Leave a review →]([link])**
>
> One thing that helps more than a star rating: if you can mention **what we did** and **where**, it makes the review far more useful to someone deciding.
>
> Thanks either way,
> [Name]

### Template B — SMS

> Hi [First name], thanks for having us out for [service] today. If you have a minute, a quick review would really help: [short link]. Mentioning the job and the area is a huge help. Thanks — [Name] at [Business]

### Template C — Follow-up, once, five days later

> **Subject:** Re: Quick favour
>
> Hi [First name] — just bumping this once in case it got buried.
>
> If [service] went well, a short review here would mean a lot: [link]
>
> And if anything wasn't right, reply to this email instead and I'll sort it.
>
> [Name]

**Send this once.** Two follow-ups is pestering, and it costs you the review you would otherwise have got.

### Template D — Replying to a positive review

> Thanks so much, [Name] — really glad the [specific service] in [area] went well. It was a pleasure working with you, and we're here if you need anything else.
> — [Your name], [Business]

Naming the service and the area in your reply is the point. Your replies are indexable content you fully control, sitting on a high-authority third-party domain.

### Template E — Replying to a negative review

> [Name], I'm sorry this fell short — that isn't the standard we work to.
>
> [One sentence acknowledging the specific issue without excuses.]
>
> I'd like to put it right. I'm at [email/phone] and I'll pick it up personally.
>
> — [Your name], [Owner/Manager], [Business]

Never argue, never blame the customer, never mention their spending. A calm, specific, non-defensive reply reads well to the next reader — and to a model summarising your reputation.

---

## Part 2 — Roundup and listicle pitches

These pages are frequently cited *instead of* businesses. Getting listed on them is usually easier than outranking them.

### Before you pitch

1. Read the article. Note how the existing entries are structured.
2. Find how inclusion works — submission form, editorial, paid placement, or just an email.
3. Check whether they have updated it recently. A page last touched in 2023 is not worth the effort.

### Template F — Cold pitch for inclusion

> **Subject:** Addition for your "[exact article title]" piece?
>
> Hi [Name],
>
> I came across your [article title] — [one genuinely specific observation about it, proving you read it].
>
> We're [Business], a [category] in [location]. We'd be a reasonable fit for the list:
>
> - [Concrete differentiator — a capability, not an adjective]
> - [Verifiable fact: years operating, size, specialism, accreditation]
> - [Proof point: rating and review count, award, registration number]
>
> Details if useful: [URL]
>
> Completely understand if it's not a fit. Either way, [genuine closing remark].
>
> [Name]
> [Business] · [Phone]

**What kills these pitches:** adjectives. "We're passionate about quality and deliver exceptional service" says nothing verifiable. "We're the only practice in Leeds with a paediatric sedation licence" is a reason to include you.

### Template G — Following up on a listing correction

> **Subject:** Small correction on your [article] listing
>
> Hi [Name],
>
> Thanks for including us in [article]. One small thing — [the detail] has changed: it's now [correct detail].
>
> Would you mind updating it when you next touch the page? Happy to send anything you need.
>
> Thanks,
> [Name]

Worth doing. An inaccurate third-party listing actively damages your entity consistency.

---

## Part 3 — Directory submissions

### The rule

Use your **canonical facts sheet** from Week 3, verbatim, every single time. Byte-identical. This is the entire point of the exercise — every inconsistency you introduce weakens the entity you are trying to build.

### Submission checklist

- [ ] Business name — exact canonical form, no variations
- [ ] Address — exact format used everywhere else
- [ ] Phone — same international format
- [ ] Website — same protocol and subdomain (`https://www.` or `https://`, pick one)
- [ ] Description — your one-sentence description, word for word
- [ ] Categories — most specific available
- [ ] Hours — matching Google Business Profile exactly
- [ ] Logo — same file, same URL
- [ ] **Add the new profile URL to your `sameAs` array and regenerate your schema**

That last step is the one everyone forgets, and it is what converts a directory listing into an identity signal.

---

## Part 4 — Podcast and guest content pitches

### Template H — Podcast pitch

> **Subject:** Guest idea: [specific, concrete topic]
>
> Hi [Name],
>
> I listened to your episode with [guest] on [topic] — [specific detail that proves you listened].
>
> I'm [Name], [role] at [Business]. I think your audience would get value from: **[specific topic angle]**.
>
> Three things I could cover:
> 1. [Concrete point with a number or finding]
> 2. [Concrete point]
> 3. [Contrarian or surprising point]
>
> I've got [relevant credential or data] to back it up — [one line of proof].
>
> Happy to send more, or leave it there if it's not right.
>
> [Name] · [Business] · [URL]

Show notes are indexable text on a domain with its own authority. Underrated, and much easier to land than press.

### Template I — Guest article pitch

> **Subject:** Article pitch: [working headline]
>
> Hi [Name],
>
> I read [specific article on their site] and noticed you haven't covered [gap].
>
> I'd like to write: **"[working headline]"**
>
> It would cover [three bullet outline], and I'd include [original data / firsthand experience / specific expertise] that isn't published anywhere else.
>
> Roughly [word count]. I can have a draft over within [timeframe].
>
> [Name], [role] at [Business] — [one line of relevant credibility]

Pitch for the **mention and the topical association**, not the backlink. Publications can tell the difference, and so, increasingly, can models.

---

## Part 5 — Journalist request responses

Services like Qwoted, Featured and SourceBottle are unglamorous and effective. Speed wins.

### Template J — Fast response

> **Re: [their query]**
>
> [Direct answer to the exact question asked, in 2–3 sentences. No preamble.]
>
> [One supporting fact, number or example.]
>
> **Attribution:** [Full name], [Title], [Business] ([URL])
> **Credentials:** [One line — why you're qualified to say this]
> **Available:** [Timeframe] on [phone/email]

**What gets you used:** answering the actual question in the first sentence, being quotable without editing, and responding within the hour. What gets you ignored: a pitch about your business, a preamble, or a 400-word essay.

---

## Part 6 — The weekly evidence habit

Thirty minutes, once a week. It is the only part of this kit that decays if you stop.

| | Task |
|---|---|
| ☐ | Send review requests to everyone you served this week |
| ☐ | Reply to every new review, naming the service and location |
| ☐ | Send two roundup or publication pitches |
| ☐ | Answer one journalist request |
| ☐ | Post one genuinely useful answer in a community where your buyers ask questions |

Small, dull, compounding. Six months of this outperforms any single tactic in the kit.

---

*CITED — The AI Search Visibility Kit · 2026 Edition. Licensed for use on sites you own or manage for clients. Not for resale or redistribution.*
