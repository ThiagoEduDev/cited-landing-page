# The 90-Day Implementation Plan

**CITED · Component 7 · 2026 Edition**

Everything in this kit, sequenced into weekly blocks of **two to four hours**. Work it in order. The order is the value — it follows the C.I.T.E. dependency chain, so you never waste effort on a layer that depends on a broken one underneath it.

> **If you only have one weekend:** do Weeks 1, 2 and 3. That is the crawlable and identity work, and it is where the disproportionate gains are.

---

## Phase 1 — Foundation (Weeks 1–4)

### Week 1 · Baseline and unblock — 3 hours

**You cannot prove improvement without a before-picture. Do this before changing anything.**

| | Task | Tool |
|---|---|---|
| ☐ | Run the full AI Visibility Scorecard. Export and save the PDF — this is your baseline. | Component 2 |
| ☐ | Run the 10 Baseline prompts on ChatGPT, Perplexity, Gemini and Google AI Mode, in logged-out sessions. | Component 5 |
| ☐ | Log every result in the Citation Tracker. Screenshot the notable ones. | Component 8 |
| ☐ | Open `yoursite.com/robots.txt`. Record exactly what it says today. | — |
| ☐ | Decide your crawler policy: maximum visibility, cited-not-trained, or blocked. | Playbook §4.2 |
| ☐ | Generate and upload a new `robots.txt`. **Back up the old one first.** | Component 4 |
| ☐ | Verify the new file is live and check it in Google Search Console. | — |

**Done when:** you have a saved baseline score, a tracker with 10 logged results, and `Google-Extended` explicitly allowed.

### Week 2 · Make yourself readable — 3 hours

| | Task | Tool |
|---|---|---|
| ☐ | View-source test on your five most important pages — is the body copy in the raw HTML? | Playbook §4.4 |
| ☐ | If not: enable SSR/static generation or prerendering. This may need your developer. | — |
| ☐ | Confirm `sitemap.xml` exists, is accurate, and is referenced in `robots.txt`. | — |
| ☐ | Check server response time. Target under 600ms. | — |
| ☐ | Remove or defer any cookie wall, age gate or modal that blocks content in the DOM. | — |
| ☐ | Audit headings: one real `<h1>` per page, semantic `<h2>`/`<h3>`, real lists and tables. | Playbook §4.5 |
| ☐ | Check canonical tags are self-referential and consistent. | — |

**Done when:** a crawler with no JavaScript engine can read your five key pages completely.

### Week 3 · Lock down your identity — 4 hours

The least glamorous week and the highest-leverage one.

| | Task | Tool |
|---|---|---|
| ☐ | Write your **canonical facts sheet**: exact legal name, trading name, address, phone, founding year, one-sentence description, logo URL, all profile URLs. | Playbook §5.1 |
| ☐ | Audit every listing against it — website, Google Business Profile, LinkedIn, directories, review platforms, socials. Fix every mismatch. | — |
| ☐ | Generate `Organization` or `LocalBusiness` schema. Populate `sameAs` with every official profile. | Component 3 |
| ☐ | Install it on your homepage. Validate at validator.schema.org and Rich Results Test. | — |
| ☐ | Rewrite your About page so the first paragraph is pure fact: founded, size, location, scope, specialism. | Template 18 |
| ☐ | If you serve a location: complete every field of your Google Business Profile. | — |

**Done when:** your business name is byte-identical everywhere, and your homepage carries validating schema with a populated `sameAs` array.

### Week 4 · Ship llms.txt and close the technical gaps — 2 hours

| | Task | Tool |
|---|---|---|
| ☐ | Build `llms.txt`: your summary, context paragraph, and 10–25 curated links with descriptions. | Component 4 |
| ☐ | Upload to site root. **Open it in a browser and confirm it renders as plain text, not a styled HTML page.** | — |
| ☐ | Work every remaining **Critical** item from your Week 1 action plan. | Component 2 |
| ☐ | Add `Person` schema to author bio pages if you publish advisory content. | Component 3 |
| ☐ | Re-run the Scorecard. Compare to baseline — the C and I bars should be near full. | Component 2 |

**Milestone:** the technical foundation is complete. Nothing is visible externally yet. **This is normal and it is where most people quit.** Keep going.

---

## Phase 2 — Content (Weeks 5–8)

### Week 5 · Find the gaps — 3 hours

| | Task | Tool |
|---|---|---|
| ☐ | Run all 10 Content Gap prompts. Save every response. | Component 5 |
| ☐ | Run the 20-common-questions prompt for each of your main services. | Component 5 |
| ☐ | Run all 10 Source Mapping prompts. **Build a list of every URL cited.** | Component 5 |
| ☐ | Sort that URL list into: roundups to pitch, directories to join, publications to approach, communities to join. | — |
| ☐ | Pick your **10 priority pages** — highest commercial value, not highest traffic. | — |

### Week 6 · Rewrite your openings — 4 hours

The single highest-return content work in the entire kit.

| | Task | Tool |
|---|---|---|
| ☐ | For each of the 10 priority pages: identify the one question it answers. | — |
| ☐ | Make that question the `<h2>`, phrased as a person would ask it. | Template group 5 |
| ☐ | Write a 40–80 word complete answer directly below it, with a specific number, date or name. | Templates 1–18 |
| ☐ | Cold-read test every one. | Answer Block Templates |
| ☐ | Move or delete the throat-clearing introduction. | — |
| ☐ | Add a visible "Last updated" date to each page. | — |

### Week 7 · Build the extractable assets — 3 hours

| | Task | Tool |
|---|---|---|
| ☐ | Build one **comparison table** for your main category. Be genuinely fair about competitors. | Template 7 |
| ☐ | Publish a **pricing block** with a real range and the drivers behind it. | Templates 4–6 |
| ☐ | Write **definition blocks** for your three core industry terms. | Templates 1–3 |
| ☐ | Write an honest **"can I do this myself?"** page. | Template 15 |
| ☐ | Build a genuine FAQ page from the questions found in Week 5. | Template group 5 |

### Week 8 · Structure it — 2 hours

| | Task | Tool |
|---|---|---|
| ☐ | Generate `FAQPage` schema for the FAQ page. **Verify every Q&A is visible on the page.** | Component 3 |
| ☐ | Generate `HowTo` schema for any genuine step-by-step content. | Component 3 |
| ☐ | Generate `Article` schema for your top 5 blog posts, with real author attribution. | Component 3 |
| ☐ | Validate everything. Fix all errors. | — |
| ☐ | Add a table of contents with anchor links to any page over 1,500 words. | — |
| ☐ | Re-run the Scorecard. The T bar should now be strong. | Component 2 |

**Milestone:** you are readable, identifiable, and quotable. Now you need corroboration.

---

## Phase 3 — Evidence (Weeks 9–12)

This phase is slower and compounds. It is also the layer that decides close calls, which is why most sites that do everything else right still lose.

### Week 9 · Turn on the review engine — 2 hours

| | Task | Tool |
|---|---|---|
| ☐ | Pick your primary review platform — the one your category actually uses. | Playbook §7.3 |
| ☐ | Build a review request into your delivery process, sent **within hours** of completion. | Outreach Templates |
| ☐ | Ask a specific question in the request so you get specific, extractable reviews. | Outreach Templates |
| ☐ | Reply to every existing review, naming the service and location naturally. | — |
| ☐ | Set a recurring weekly reminder to send requests. Never let this lapse. | — |

**Never** buy reviews, incentivize positive-only reviews, or gate requests to happy customers. It breaches platform terms and consumer-protection law, and it is the fastest way to lose a profile entirely.

### Week 10 · Get listed — 3 hours

| | Task | Tool |
|---|---|---|
| ☐ | Submit to every directory from your Week 5 source map. Use canonical facts exactly. | Week 3 facts sheet |
| ☐ | Join your industry association or registry if you qualify. | — |
| ☐ | Claim Apple Business Connect and Bing Places. | — |
| ☐ | Add every new profile URL to your `sameAs` array and regenerate your schema. | Component 3 |

### Week 11 · Pitch the roundups — 3 hours

| | Task | Tool |
|---|---|---|
| ☐ | Take the roundup list from Week 5. For each, find how inclusion works. | — |
| ☐ | Send 10 pitches. Facts and one concrete differentiator — no adjectives. | Outreach Templates |
| ☐ | Sign up to one journalist request service and set up alerts. | Playbook §7.4 |
| ☐ | Pitch two podcasts or publications in your category. | Outreach Templates |

### Week 12 · Measure, and set the cadence — 2 hours

| | Task | Tool |
|---|---|---|
| ☐ | Re-run all 60 prompts. Log everything. | Components 5 & 8 |
| ☐ | Compare against your Week 1 baseline, prompt by prompt. | Component 8 |
| ☐ | Re-run the full Scorecard. Compare all four bars to baseline. | Component 2 |
| ☐ | Check analytics for referrals from `chatgpt.com`, `perplexity.ai`, `gemini.google.com`, `copilot.microsoft.com`. | — |
| ☐ | Screenshot every new citation. These are your proof — and your case studies. | — |
| ☐ | Set recurring calendar entries: monthly prompt run, quarterly full re-audit. | — |

---

## What to expect, honestly

| Window | What typically shifts |
|---|---|
| Week 1 | Scorecard jumps. Nothing visible externally. |
| Weeks 2–6 | Crawlers revisit, schema is picked up, assistants describe you more accurately when asked by name. |
| Weeks 6–12 | First unprompted mentions — long-tail and specific before broad and competitive. |
| Months 3–6 | Evidence compounds. Broader, more competitive prompts start returning you. |

Being named for "best [category] in [city]" is a twelve-month project. Being named for "[category] in [city] that does [specific thing] for [specific customer]" is a six-week project — **and it converts better anyway.**

Start narrow. Win the specific queries. Widen from there.

---

## The permanent cadence, after day 90

- **Weekly** — send review requests, reply to every review
- **Monthly** — run your 20 core prompts, log results, note new competitors
- **Monthly** — check AI referral traffic and, more importantly, its conversion rate
- **Quarterly** — full Scorecard re-audit; review `llms.txt`, schema and canonical facts for drift
- **Quarterly** — publish one new extractable asset: original data, a comparison, or a definitive guide

The technical layers stay fixed once fixed. Evidence is the only part that decays if you stop.

---

*CITED — The AI Search Visibility Kit · 2026 Edition. This plan describes structural best practice. It does not guarantee citation, ranking or traffic outcomes, which are controlled by third-party systems that change without notice.*
