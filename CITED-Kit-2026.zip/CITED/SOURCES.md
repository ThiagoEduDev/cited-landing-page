# Sources

**CITED — The AI Search Visibility Kit · 2026 Edition**
Research compiled 21 September 2026.

Every external statistic used in this kit and in its marketing is listed here with its source and the date it was gathered. Check them yourself — and check how old they are before you rely on them. This field moves quickly.

---

## Search behavior and zero-click

| Claim used | Source |
|---|---|
| 68.01% of US Google searches ended without a click in early 2026, up from 60.45% in 2024 | [SparkToro](https://sparktoro.com/blog/in-2026-less-than-one-third-of-google-searches-still-send-a-click/) · [Omnibound](https://www.omnibound.ai/blog/zero-click-search-statistics) |
| AI Overviews appear on ~48% of SERPs | [Omnibound](https://www.omnibound.ai/blog/zero-click-search-statistics) |
| AI Overviews reduce organic CTR by ~61% | [Omnibound](https://www.omnibound.ai/blog/ai-seo-statistics) |
| 83% zero-click rate on queries with an AI Overview; 93% in Google AI Mode | [Strategyc](https://www.strategyc.io/blog/zero-click-search-statistics) · [click-vision](https://click-vision.com/zero-click-search-statistics) |
| Organic traffic down 15–25% on average; 40–70% in some sectors | [Omnibound](https://www.omnibound.ai/blog/ai-seo-statistics) |
| AI Overview penetration by sector: Health 43.0%, E-commerce 3.2% | [Omnibound](https://www.omnibound.ai/blog/ai-seo-statistics) |
| Brands cited in AI Overviews see +35% organic CTR and +91% paid CTR | [Omnibound](https://www.omnibound.ai/blog/zero-click-search-statistics) |
| General coverage of AI Overviews and traffic loss | [Forbes, May 2026](https://www.forbes.com/sites/terdawn-deboe/2026/05/18/google-ai-overviews-are-eating-your-website-traffic-fight-back/) |

## AI assistant usage

| Claim used | Source |
|---|---|
| ChatGPT ~1 billion weekly active users in 2026, up from ~400M eighteen months earlier | [Search Engine Journal](https://www.searchenginejournal.com/ai-overview-recommendation-plan-reviewly-spa/587030/) |
| ChatGPT reaches 883 million monthly users | [WRITER](https://writer.com/blog/geo-aeo-optimization/) |
| A large share of assistant sessions are recommendation-intent queries | [Search Engine Journal](https://www.searchenginejournal.com/ai-overview-recommendation-plan-reviewly-spa/587030/) |

## Structured data and citation

| Claim used | Source |
|---|---|
| ~71% of pages cited by ChatGPT contain structured data; ~65% of pages cited by Google AI Mode | [Walker Sands](https://www.walkersands.com/about/blog/how-can-schema-markup-support-llm-visibility/) |
| Sites with detailed schema markup are cited 3–8× more often | [Search Engine Journal](https://www.searchenginejournal.com/ai-overview-recommendation-plan-reviewly-spa/587030/) |
| Most useful schema types for AI visibility: Article, FAQPage, HowTo, Organization, Product | [Derivatex](https://derivatex.agency/blog/schema-markup-llm-seo/) · [Walker Sands](https://www.walkersands.com/about/blog/how-can-schema-markup-support-llm-visibility/) |
| llms.txt purpose and structure | [Yotpo](https://www.yotpo.com/blog/what-is-llms-txt/) · [ElmoHQ](https://www.elmohq.com/blog/structured-data-for-ai-search) |

## Market pricing (used for value anchoring)

All figures are published prices gathered 21 September 2026.

| Offering | Price | Source |
|---|---|---|
| Otterly Lite / Standard / Premium | $29 / $189 / $489 per month | [get-ryze](https://www.get-ryze.ai/blog/ai-visibility-tools-pricing-compared-2026) · [criticnest](https://criticnest.com/ai-visibility-tools-pricing/) |
| Otterly Enterprise | from $1,000/month | [criticnest](https://criticnest.com/ai-visibility-tools-pricing/) |
| Peec AI Starter → Advanced | $95 → $495/month | [get-ryze](https://www.get-ryze.ai/blog/ai-visibility-tools-pricing-compared-2026) |
| AthenaHQ self-serve | $245–$295/month | [get-ryze](https://www.get-ryze.ai/blog/ai-visibility-tools-pricing-compared-2026) |
| Profound Growth → Enterprise | $399/month → thousands | [criticnest](https://criticnest.com/ai-visibility-tools-pricing/) |
| Standalone AI visibility / schema-gap audit | $800–$7,500 one-time | [fuelonline](https://fuelonline.com/ai-seo-geo/ai-seo-pricing-aeo-geo-cost-2026/) |
| One-time GEO audit | $1,500–$5,000 (up to $8,000–$25,000 for large sites) | [stackmatix](https://www.stackmatix.com/blog/aeo-optimization-cost) · [outreachbloom](https://outreachbloom.com/aeo-geo-pricing-guide/) |
| Ongoing AEO/GEO retainer | $2,000–$20,000/month | [fuelonline](https://fuelonline.com/ai-seo-geo/ai-seo-pricing-aeo-geo-cost-2026/) |
| Experienced freelancer | $125–$250/hour; $3,500–$6,000/month | [humanswith.ai](https://humanswith.ai/blog/what-aeo-and-geo-actually-cost-in-2026/) |
| GEO added to existing SEO retainer | +20–30% MRR | [outreachbloom](https://outreachbloom.com/aeo-geo-pricing-guide/) |

## Local business AI visibility

| Claim used | Source |
|---|---|
| Proximity-first vs reputation-first query split | [Search Engine Journal](https://www.searchenginejournal.com/ai-overview-recommendation-plan-reviewly-spa/587030/) |
| Review recency, GBP completeness and site consistency as dominant local levers | [Search Engine Journal](https://www.searchenginejournal.com/ai-overview-recommendation-plan-reviewly-spa/587030/) · [CMC SEO](https://cmc-seo.com/chatgpt-recommends-local-businesses/) |
| AI assistants draw on structured sources (Google Business, Yelp, Facebook, review schema) | [DEV Community](https://dev.to/renai/blog-top-5-mistakes-small-businesses-make-with-chatgpt-and-how-to-fix-them-2fm6) |

## General AEO/GEO practice

- [Frase — Complete AEO Guide 2026](https://www.frase.io/blog/what-is-answer-engine-optimization-the-complete-guide-to-getting-cited-by-ai)
- [WRITER — GEO, AEO and SEO in 2026](https://writer.com/blog/geo-aeo-optimization/)
- [Jasper — GEO vs AEO vs SEO](https://www.jasper.ai/blog/geo-aeo)
- [Powered by Search — AEO best practices](https://www.poweredbysearch.com/blog/aeo-llm-seo-best-practices/)

---

## A note on reading these numbers

Several of these figures come from vendor blogs and marketing research rather than peer-reviewed sources, and vendors in this category have an obvious commercial interest in the numbers being large. Where multiple independent sources agreed, that is noted above by listing more than one.

Treat the direction of these figures as reliable and the precise decimal places as approximate. The underlying trend — that a large and growing share of searches resolve without a click, and that citation is replacing ranking as the thing worth competing for — is corroborated across every source consulted.

Statistics are dated because they will age. Re-check anything you quote publicly.
